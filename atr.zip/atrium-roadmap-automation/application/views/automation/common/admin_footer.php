<!-- Main Footer -->
<footer class="main-footer">
  <strong>Copyright &copy; 2021 <a href="javascript:void(0);">Admin Panel</a>.</strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 3.0.5
  </div>
</footer>
</div>
<!-- ./wrapper -->
<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="../assets/roadmap-automation/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../assets/roadmap-automation/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- moment -->
<script src="../assets/roadmap-automation/moment/moment.min.js"></script>
<!-- date-range-picker -->
<script src="../assets/roadmap-automation/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="../assets/roadmap-automation/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- custom js -->
<script src="../assets/roadmap-automation/js/custom.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
</body>

</html>